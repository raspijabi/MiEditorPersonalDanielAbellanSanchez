package hiloCoherencia;

import ventana.Ventana;

public class Coherencia implements Runnable {

	public Ventana accesibilidad;

	@Override
	public void run() {
		accesibilidad.getPanelGeneral().getPanelEditor().getPanelScroll().getPanelTexto().coherenciaDeLaInterfaz();
	}

}
