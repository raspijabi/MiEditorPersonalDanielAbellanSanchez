package componentes;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GraphicsEnvironment;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.ResourceBundle;

import javax.swing.ButtonGroup;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JColorChooser;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JToggleButton;
import javax.swing.JToolBar;
import javax.swing.ListCellRenderer;
import javax.swing.text.SimpleAttributeSet;
import javax.swing.text.StyleConstants;
import javax.swing.text.StyledEditorKit;

import ventana.Ventana;

public class BarraDeHerramientas extends JToolBar {

	private JToggleButton negrita, cursiva, subrayado, alineacionIzq, alineacionCen, alineacionDer, alineacionJust;
	private JButton nuevo, guardar, colorTexto, insertarImagen;
	private JComboBox<Integer> listaDesplegableTamanyo;
	private JComboBox listaDesplegableFuentes;
	private Ventana accesibilidad;
	private ButtonGroup grupoBotones;
	String fontName[];
	Integer array[];
	private ArrayList<Integer> arrayTama;

	public BarraDeHerramientas() {

		// Atributos de la barra de herramientas
		Dimension dimensionBotones = new Dimension(60, 60);
		this.setFloatable(false);
		this.setBackground(Color.WHITE);
		this.setFocusable(false);
		// BOTONES
		nuevo = new JButton();
		nuevo.setToolTipText(ResourceBundle.getBundle("resources.lenguajes.Lenguaje").getString("submenu_nuevo"));
		nuevo.setPreferredSize(dimensionBotones);
		nuevo.setFont(new Font("SANS_SERIF", 1, 20));
		nuevo.setBorder(null);
		nuevo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				accesibilidad.getMenuPrincipal().nuevo();
			}
		});
		try {
			Icon nuev = new ImageIcon(new ImageIcon("./src/resources/icons/nuevo.png").getImage().getScaledInstance(40,
					40, Image.SCALE_SMOOTH));
			nuevo.setIcon(nuev);
		} catch (Exception e) {

		}

		nuevo.setOpaque(false);

		guardar = new JButton();
		guardar.setToolTipText(ResourceBundle.getBundle("resources.lenguajes.Lenguaje").getString("submenu_guardar"));
		guardar.setPreferredSize(dimensionBotones);
		guardar.setFont(new Font("SANS_SERIF", 1, 20));
		guardar.setBorder(null);
		guardar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				accesibilidad.getMenuPrincipal().guardar();
			}
		});
		try {
			Icon guarda = new ImageIcon(new ImageIcon("./src/resources/icons/guardar.png").getImage()
					.getScaledInstance(40, 40, Image.SCALE_SMOOTH));
			guardar.setIcon(guarda);
		} catch (Exception e) {

		}

		guardar.setOpaque(false);

		colorTexto = new JButton();
		colorTexto
				.setToolTipText(ResourceBundle.getBundle("resources.lenguajes.Lenguaje").getString("hint_colorTexto"));
		colorTexto.setPreferredSize(dimensionBotones);
		colorTexto.setFont(new Font("SANS_SERIF", 1, 20));
		colorTexto.setBorder(null);
		// HAY QUE DEFINIR EL METODO DE CAMBIAR COLOR
		colorTexto.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cambiarColorTexto();
			}
		});
		try {
			Icon colo = new ImageIcon(new ImageIcon("./src/resources/icons/colorTexto.png").getImage()
					.getScaledInstance(50, 50, Image.SCALE_SMOOTH));
			colorTexto.setIcon(colo);
		} catch (Exception e) {

		}

		colorTexto.setOpaque(false);

		insertarImagen = new JButton();
		insertarImagen
				.setToolTipText(ResourceBundle.getBundle("resources.lenguajes.Lenguaje").getString("submenu_imagen"));
		insertarImagen.setPreferredSize(dimensionBotones);
		insertarImagen.setFont(new Font("SANS_SERIF", 1, 20));
		insertarImagen.setBorder(null);
		insertarImagen.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				accesibilidad.getMenuPrincipal().imagen();
			}
		});
		try {
			Icon img = new ImageIcon(new ImageIcon("./src/resources/icons/imagen.png").getImage().getScaledInstance(40,
					40, Image.SCALE_SMOOTH));
			insertarImagen.setIcon(img);
		} catch (Exception e) {

		}

		insertarImagen.setOpaque(false);

		alineacionCen = new JToggleButton();
		alineacionCen.setToolTipText(ResourceBundle.getBundle("resources.lenguajes.Lenguaje").getString("ali_centro"));
		alineacionCen.setPreferredSize(dimensionBotones);
		alineacionCen.setFont(new Font("SANS_SERIF", 1, 20));
		alineacionCen.setBorder(null);
		alineacionCen.addActionListener(new StyledEditorKit.AlignmentAction(null, StyleConstants.ALIGN_CENTER));
		try {
			Icon alineacionC = new ImageIcon(new ImageIcon("./src/resources/icons/alineacionCentrada.png").getImage()
					.getScaledInstance(40, 40, Image.SCALE_SMOOTH));
			alineacionCen.setIcon(alineacionC);
		} catch (Exception e) {

		}

		alineacionCen.setOpaque(false);

		alineacionIzq = new JToggleButton();
		alineacionIzq
				.setToolTipText(ResourceBundle.getBundle("resources.lenguajes.Lenguaje").getString("ali_izquierda"));
		alineacionIzq.setPreferredSize(dimensionBotones);
		alineacionIzq.setFont(new Font("SANS_SERIF", 1, 20));
		alineacionIzq.setBorder(null);
		alineacionIzq.addActionListener(new StyledEditorKit.AlignmentAction(null, StyleConstants.ALIGN_LEFT));
		try {
			Icon aliI = new ImageIcon(new ImageIcon("./src/resources/icons/alineacionIzquierda.png").getImage()
					.getScaledInstance(40, 40, Image.SCALE_SMOOTH));
			alineacionIzq.setIcon(aliI);
		} catch (Exception e) {

		}

		alineacionIzq.setOpaque(false);

		alineacionDer = new JToggleButton();
		alineacionDer.setToolTipText(ResourceBundle.getBundle("resources.lenguajes.Lenguaje").getString("ali_derecha"));
		alineacionDer.setPreferredSize(dimensionBotones);
		alineacionDer.setFont(new Font("SANS_SERIF", 1, 20));
		alineacionDer.setBorder(null);
		alineacionDer.addActionListener(new StyledEditorKit.AlignmentAction(null, StyleConstants.ALIGN_RIGHT));
		try {
			Icon aliD = new ImageIcon(new ImageIcon("./src/resources/icons/alineacionDerecha.png").getImage()
					.getScaledInstance(40, 40, Image.SCALE_SMOOTH));
			alineacionDer.setIcon(aliD);
		} catch (Exception e) {

		}

		alineacionDer.setOpaque(false);

		alineacionJust = new JToggleButton();
		alineacionJust
				.setToolTipText(ResourceBundle.getBundle("resources.lenguajes.Lenguaje").getString("ali_justificada"));
		alineacionJust.setPreferredSize(dimensionBotones);
		alineacionJust.setFont(new Font("SANS_SERIF", 1, 20));
		alineacionJust.setBorder(null);
		alineacionJust.addActionListener(new StyledEditorKit.AlignmentAction(null, StyleConstants.ALIGN_JUSTIFIED));
		try {
			Icon aliJ = new ImageIcon(new ImageIcon("./src/resources/icons/alineacionJustificada.png").getImage()
					.getScaledInstance(40, 40, Image.SCALE_SMOOTH));
			alineacionJust.setIcon(aliJ);
		} catch (Exception e) {

		}

		alineacionJust.setOpaque(false);

		negrita = new JToggleButton();
		negrita.setToolTipText(ResourceBundle.getBundle("resources.lenguajes.Lenguaje").getString("negrita"));
		negrita.setFocusable(false);
		negrita.setPreferredSize(dimensionBotones);
		negrita.setFont(new Font("SANS_SERIF", 1, 20));
		negrita.setBorder(null);
		negrita.addActionListener(new StyledEditorKit.BoldAction());
		try {
			Icon negrit = new ImageIcon(new ImageIcon("./src/resources/icons/negrita.png").getImage()
					.getScaledInstance(50, 50, Image.SCALE_SMOOTH));
			negrita.setIcon(negrit);
		} catch (Exception e) {

		}

		negrita.setOpaque(false);

		cursiva = new JToggleButton();
		cursiva.setFocusable(false);
		cursiva.setToolTipText(ResourceBundle.getBundle("resources.lenguajes.Lenguaje").getString("cursiva"));
		cursiva.setPreferredSize(dimensionBotones);
		cursiva.setFont(new Font("SANS_SERIF", 1, 20));
		cursiva.setBorder(null);
		cursiva.addActionListener(new StyledEditorKit.ItalicAction());
		try {
			Icon cursiv = new ImageIcon(new ImageIcon("./src/resources/icons/cursiva.png").getImage()
					.getScaledInstance(50, 50, Image.SCALE_SMOOTH));
			cursiva.setIcon(cursiv);
		} catch (Exception e) {

		}

		cursiva.setOpaque(false);

		subrayado = new JToggleButton();
		subrayado.setFocusable(false);
		subrayado.setToolTipText(ResourceBundle.getBundle("resources.lenguajes.Lenguaje").getString("subrayado"));
		subrayado.setPreferredSize(dimensionBotones);
		subrayado.setFont(new Font("SANS_SERIF", 1, 20));
		subrayado.setBorder(null);
		subrayado.addActionListener(new StyledEditorKit.UnderlineAction());
		try {
			Icon subra = new ImageIcon(new ImageIcon("./src/resources/icons/subrayado.png").getImage()
					.getScaledInstance(50, 50, Image.SCALE_SMOOTH));
			subrayado.setIcon(subra);
		} catch (Exception e) {

		}

		subrayado.setOpaque(false);

		// A�ADIMOS LAS ALINEACIONES AL BUTTON GROUP
		grupoBotones = new ButtonGroup();
		grupoBotones.add(alineacionIzq);
		grupoBotones.add(alineacionCen);
		grupoBotones.add(alineacionDer);
		grupoBotones.add(alineacionJust);

		// LISTA DESPLEGABLE TAMA�O
		listaDesplegableTamanyo = new JComboBox<Integer>();
		listaDesplegableTamanyo
				.setToolTipText(ResourceBundle.getBundle("resources.lenguajes.Lenguaje").getString("hint_tamanyo"));
		arrayTama = new ArrayList<Integer>();

		for (int i = 10; i < 48; i = i + 2) {
			arrayTama.add(i);
		}
		for (Integer i : arrayTama) {
			listaDesplegableTamanyo.addItem(i);
		}

		listaDesplegableTamanyo.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				cambiarTamanyoFuente(e, listaDesplegableTamanyo.getSelectedItem().toString());
			}
		});
		listaDesplegableTamanyo.setFont(new Font("SANS_SERIF", 1, 16));
		listaDesplegableTamanyo.setMaximumSize(new Dimension(100, 40));

		// LISTA DESPLEGABLE FUENTES
		// Creamos el combobox
		GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
		fontName = ge.getAvailableFontFamilyNames();
		array = new Integer[fontName.length];
		for (int i = 1; i <= fontName.length; i++) {
			array[i - 1] = i;
		}

		listaDesplegableFuentes = new JComboBox(array);
		listaDesplegableFuentes
				.setToolTipText(ResourceBundle.getBundle("resources.lenguajes.Lenguaje").getString("hint_fuente"));
		ComboBoxRenderar renderar = new ComboBoxRenderar();
		listaDesplegableFuentes.setRenderer(renderar);

		listaDesplegableFuentes.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				cambiarTipoDeFuente(e, fontName[listaDesplegableFuentes.getSelectedIndex()]);
				listaDesplegableFuentes.setFont(new Font(fontName[listaDesplegableFuentes.getSelectedIndex()], 1, 16));
			}
		});
		listaDesplegableFuentes.setFont(new Font("SANS_SERIF", 1, 16));
		listaDesplegableFuentes.setMaximumSize(new Dimension(300, 40));

		// a�adimos los componentes a la barra de tareas

		this.add(nuevo);
		this.add(guardar);
		this.addSeparator();
		this.add(listaDesplegableTamanyo);
		this.addSeparator();
		this.add(listaDesplegableFuentes);
		this.addSeparator();
		this.add(negrita);
		this.add(cursiva);
		this.add(subrayado);
		this.addSeparator();
		this.add(colorTexto);
		this.addSeparator();
		this.add(alineacionIzq);
		this.add(alineacionCen);
		this.add(alineacionDer);
		this.add(alineacionJust);
		this.addSeparator();
		this.add(insertarImagen);
		this.setVisible(true);
	}

	public void negrita() {
		new StyledEditorKit.BoldAction();
		accesibilidad.getPanelGeneral().getPanelEditor().getPanelScroll().getPanelTexto().coherenciaDeLaInterfaz();
	}

	public class ComboBoxRenderar extends JLabel implements ListCellRenderer {

		@Override
		public Component getListCellRendererComponent(JList list, Object value, int index, boolean isSelected,
				boolean cellHasFocus) {
			int offset = ((Integer) value).intValue() - 1;
			String name = fontName[offset];
			setText(name);
			setFont(new Font(name, Font.PLAIN, 20));
			return this;
		}
	}

	public void cambiarTamanyoFuente(ActionEvent e, String tamanyo) {
		new StyledEditorKit.FontSizeAction("", Integer.parseInt(tamanyo)).actionPerformed(e);
	}

	public void cambiarTipoDeFuente(ActionEvent e, String fuente) {
		new StyledEditorKit.FontFamilyAction("", fuente).actionPerformed(e);
	}

	public void cambiarColorTexto() {
		SimpleAttributeSet attr = new SimpleAttributeSet();
		Color color = JColorChooser.showDialog(null,
				ResourceBundle.getBundle("resources.lenguajes.Lenguaje").getString("seleccione_un_color"), Color.BLACK);
		StyleConstants.setForeground(attr, color);
		accesibilidad.getPanelGeneral().getPanelEditor().getPanelScroll().getPanelTexto().setCharacterAttributes(attr,
				false);
	}

	public JToggleButton getNegrita() {
		return negrita;
	}

	public void setNegrita(JToggleButton negrita) {
		this.negrita = negrita;
	}

	public JToggleButton getCursiva() {
		return cursiva;
	}

	public void setCursiva(JToggleButton cursiva) {
		this.cursiva = cursiva;
	}

	public JToggleButton getSubrayado() {
		return subrayado;
	}

	public void setSubrayado(JToggleButton subrayado) {
		this.subrayado = subrayado;
	}

	public JComboBox<Integer> getListaDesplegableTamanyo() {
		return listaDesplegableTamanyo;
	}

	public void setListaDesplegableTamanyo(JComboBox<Integer> listaDesplegableTamanyo) {
		this.listaDesplegableTamanyo = listaDesplegableTamanyo;
	}

	public JComboBox getListaDesplegableFuentes() {
		return listaDesplegableFuentes;
	}

	public void setListaDesplegableFuentes(JComboBox listaDesplegableFuentes) {
		this.listaDesplegableFuentes = listaDesplegableFuentes;
	}

	public Ventana getAccesibilidad() {
		return accesibilidad;
	}

	public void setAccesibilidad(Ventana accesibilidad) {
		this.accesibilidad = accesibilidad;
	}

	public JToggleButton getAlineacionIzq() {
		return alineacionIzq;
	}

	public void setAlineacionIzq(JToggleButton alineacionIzq) {
		this.alineacionIzq = alineacionIzq;
	}

	public JToggleButton getAlineacionCen() {
		return alineacionCen;
	}

	public void setAlineacionCen(JToggleButton alineacionCen) {
		this.alineacionCen = alineacionCen;
	}

	public JToggleButton getAlineacionDer() {
		return alineacionDer;
	}

	public void setAlineacionDer(JToggleButton alineacionDer) {
		this.alineacionDer = alineacionDer;
	}

	public JToggleButton getAlineacionJust() {
		return alineacionJust;
	}

	public void setAlineacionJust(JToggleButton alineacionJust) {
		this.alineacionJust = alineacionJust;
	}

	public JButton getNuevo() {
		return nuevo;
	}

	public void setNuevo(JButton nuevo) {
		this.nuevo = nuevo;
	}

	public JButton getGuardar() {
		return guardar;
	}

	public void setGuardar(JButton guardar) {
		this.guardar = guardar;
	}

	public JButton getColorTexto() {
		return colorTexto;
	}

	public void setColorTexto(JButton colorTexto) {
		this.colorTexto = colorTexto;
	}

	public JButton getInsertarImagen() {
		return insertarImagen;
	}

	public void setInsertarImagen(JButton insertarImagen) {
		this.insertarImagen = insertarImagen;
	}

	public ButtonGroup getGrupoBotones() {
		return grupoBotones;
	}

	public void setGrupoBotones(ButtonGroup grupoBotones) {
		this.grupoBotones = grupoBotones;
	}

	public String[] getFontName() {
		return fontName;
	}

	public void setFontName(String[] fontName) {
		this.fontName = fontName;
	}

	public Integer[] getArray() {
		return array;
	}

	public void setArray(Integer[] array) {
		this.array = array;
	}

	public ArrayList<Integer> getArrayTama() {
		return arrayTama;
	}

	public void setArrayTama(ArrayList<Integer> arrayTama) {
		this.arrayTama = arrayTama;
	}

}
