package componentes;

import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ResourceBundle;

import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JMenuItem;
import javax.swing.JPopupMenu;
import javax.swing.text.StyleConstants;
import javax.swing.text.StyledEditorKit;

import ventana.Ventana;

public class MenuContextual extends JPopupMenu {

	private Ventana accesibilidad;

	private JMenuItem negrita, cursiva, subrayado, insertarImagen, aliIzq, aliDere, aliCentro, aliJustifi;

	public MenuContextual() {

		// Les ponemos las etiquetas

		negrita = new JMenuItem(ResourceBundle.getBundle("resources.lenguajes.Lenguaje").getString("negrita"));
		negrita.setToolTipText(ResourceBundle.getBundle("resources.lenguajes.Lenguaje").getString("negrita"));
		cursiva = new JMenuItem(ResourceBundle.getBundle("resources.lenguajes.Lenguaje").getString("cursiva"));
		cursiva.setToolTipText(ResourceBundle.getBundle("resources.lenguajes.Lenguaje").getString("cursiva"));
		subrayado = new JMenuItem(ResourceBundle.getBundle("resources.lenguajes.Lenguaje").getString("subrayado"));
		subrayado.setToolTipText(ResourceBundle.getBundle("resources.lenguajes.Lenguaje").getString("subrayado"));
		aliIzq = new JMenuItem(ResourceBundle.getBundle("resources.lenguajes.Lenguaje").getString("ali_izquierda"));
		aliIzq.setToolTipText(ResourceBundle.getBundle("resources.lenguajes.Lenguaje").getString("ali_izquierda"));
		aliDere = new JMenuItem(ResourceBundle.getBundle("resources.lenguajes.Lenguaje").getString("ali_derecha"));
		aliDere.setToolTipText(ResourceBundle.getBundle("resources.lenguajes.Lenguaje").getString("ali_derecha"));
		aliCentro = new JMenuItem(ResourceBundle.getBundle("resources.lenguajes.Lenguaje").getString("ali_centro"));
		aliCentro.setToolTipText(ResourceBundle.getBundle("resources.lenguajes.Lenguaje").getString("ali_centro"));
		aliJustifi = new JMenuItem(
				ResourceBundle.getBundle("resources.lenguajes.Lenguaje").getString("ali_justificada"));
		aliJustifi
				.setToolTipText(ResourceBundle.getBundle("resources.lenguajes.Lenguaje").getString("ali_justificada"));
		insertarImagen = new JMenuItem(
				ResourceBundle.getBundle("resources.lenguajes.Lenguaje").getString("submenu_imagen"));
		insertarImagen
				.setToolTipText(ResourceBundle.getBundle("resources.lenguajes.Lenguaje").getString("submenu_imagen"));

		// A�adimos la funcionalidad

		negrita.addActionListener(new StyledEditorKit.BoldAction());
		try {
			Icon negr = new ImageIcon(new ImageIcon("./src/resources/icons/negrita.png").getImage()
					.getScaledInstance(30, 30, Image.SCALE_SMOOTH));
			negrita.setIcon(negr);
		} catch (Exception e) {

		}

		cursiva.addActionListener(new StyledEditorKit.ItalicAction());
		try {
			Icon cursi = new ImageIcon(new ImageIcon("./src/resources/icons/cursiva.png").getImage()
					.getScaledInstance(30, 30, Image.SCALE_SMOOTH));
			cursiva.setIcon(cursi);

		} catch (Exception e) {

		}

		subrayado.addActionListener(new StyledEditorKit.UnderlineAction());
		try {
			Icon subra = new ImageIcon(new ImageIcon("./src/resources/icons/subrayado.png").getImage()
					.getScaledInstance(30, 30, Image.SCALE_SMOOTH));
			subrayado.setIcon(subra);
		} catch (Exception e) {

		}

		aliIzq.addActionListener(new StyledEditorKit.AlignmentAction(null, StyleConstants.ALIGN_LEFT));
		try {
			Icon aliI = new ImageIcon(new ImageIcon("./src/resources/icons/alineacionIzquierda.png").getImage()
					.getScaledInstance(30, 30, Image.SCALE_SMOOTH));
			aliIzq.setIcon(aliI);
		} catch (Exception e) {

		}

		aliDere.addActionListener(new StyledEditorKit.AlignmentAction(null, StyleConstants.ALIGN_RIGHT));
		try {
			Icon aliD = new ImageIcon(new ImageIcon("./src/resources/icons/alineacionDerecha.png").getImage()
					.getScaledInstance(30, 30, Image.SCALE_SMOOTH));
			aliDere.setIcon(aliD);
		} catch (Exception e) {

		}

		aliCentro.addActionListener(new StyledEditorKit.AlignmentAction(null, StyleConstants.ALIGN_CENTER));
		try {
			Icon aliCent = new ImageIcon(new ImageIcon("./src/resources/icons/alineacionCentrada.png").getImage()
					.getScaledInstance(30, 30, Image.SCALE_SMOOTH));
			aliCentro.setIcon(aliCent);
		} catch (Exception e) {

		}

		aliJustifi.addActionListener(new StyledEditorKit.AlignmentAction(null, StyleConstants.ALIGN_JUSTIFIED));
		try {
			Icon aliJ = new ImageIcon(new ImageIcon("./src/resources/icons/alineacionJustificada.png").getImage()
					.getScaledInstance(30, 30, Image.SCALE_SMOOTH));
			aliJustifi.setIcon(aliJ);
		} catch (Exception e) {

		}

		insertarImagen.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				accesibilidad.getMenuPrincipal().imagen();
			}
		});
		try {
			Icon img = new ImageIcon(new ImageIcon("./src/resources/icons/imagen.png").getImage().getScaledInstance(30,
					30, Image.SCALE_SMOOTH));
			insertarImagen.setIcon(img);
		} catch (Exception e) {

		}

		// a�adimos los menus al menu contextual
		this.add(negrita);
		this.add(cursiva);
		this.add(subrayado);
		this.addSeparator();
		this.add(aliIzq);
		this.add(aliCentro);
		this.add(aliDere);
		this.add(aliJustifi);
		this.addSeparator();
		this.add(insertarImagen);

	}

	public Ventana getAccesibilidad() {
		return accesibilidad;
	}

	public void setAccesibilidad(Ventana accesibilidad) {
		this.accesibilidad = accesibilidad;
	}

	public JMenuItem getNegrita() {
		return negrita;
	}

	public void setNegrita(JMenuItem negrita) {
		this.negrita = negrita;
	}

	public JMenuItem getCursiva() {
		return cursiva;
	}

	public void setCursiva(JMenuItem cursiva) {
		this.cursiva = cursiva;
	}

	public JMenuItem getSubrayado() {
		return subrayado;
	}

	public void setSubrayado(JMenuItem subrayado) {
		this.subrayado = subrayado;
	}

	public JMenuItem getInsertarImagen() {
		return insertarImagen;
	}

	public void setInsertarImagen(JMenuItem insertarImagen) {
		this.insertarImagen = insertarImagen;
	}

	public JMenuItem getAliIzq() {
		return aliIzq;
	}

	public void setAliIzq(JMenuItem aliIzq) {
		this.aliIzq = aliIzq;
	}

	public JMenuItem getAliDere() {
		return aliDere;
	}

	public void setAliDere(JMenuItem aliDere) {
		this.aliDere = aliDere;
	}

	public JMenuItem getAliCentro() {
		return aliCentro;
	}

	public void setAliCentro(JMenuItem aliCentro) {
		this.aliCentro = aliCentro;
	}

	public JMenuItem getAliJustifi() {
		return aliJustifi;
	}

	public void setAliJustifi(JMenuItem aliJustifi) {
		this.aliJustifi = aliJustifi;
	}

}
