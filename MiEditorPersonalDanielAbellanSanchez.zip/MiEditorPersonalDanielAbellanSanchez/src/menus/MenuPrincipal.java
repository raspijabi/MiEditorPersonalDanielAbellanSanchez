package menus;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.util.Locale;
import java.util.ResourceBundle;

import javax.swing.BorderFactory;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenuBar;
import javax.swing.KeyStroke;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.UIManager.LookAndFeelInfo;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.text.StyleConstants;
import javax.swing.text.StyledDocument;
import javax.swing.text.StyledEditorKit;
import javax.swing.text.rtf.RTFEditorKit;

import ventana.Ventana;

public class MenuPrincipal extends JMenuBar {

	private Ventana accesibilidad;
	private MenuBasico archivo, formato, insertar, ajustes, ayuda, fuente, alineacion, interfaz, idioma;
	private MenuItem nuevo, guardar, negrita, cursiva, subrayado, aliIzq, aliDer, aliJust, aliCentra, imagen,
			acerca_del_programa, idiomaEspaniol, idiomaIngles;

	public MenuPrincipal() {

		// Atributos
		this.setBounds(0, 0, 100, 50);
		this.setBackground(Color.WHITE);
		this.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, Color.LIGHT_GRAY));

		// Menus principales
		archivo = new MenuBasico(ResourceBundle.getBundle("resources.lenguajes.Lenguaje").getString("menu_archivo"));
		archivo.setToolTipText(ResourceBundle.getBundle("resources.lenguajes.Lenguaje").getString("menu_archivo"));
		formato = new MenuBasico(ResourceBundle.getBundle("resources.lenguajes.Lenguaje").getString("menu_formato"));
		formato.setToolTipText(ResourceBundle.getBundle("resources.lenguajes.Lenguaje").getString("menu_formato"));
		ajustes = new MenuBasico(ResourceBundle.getBundle("resources.lenguajes.Lenguaje").getString("menu_ajustes"));
		ajustes.setToolTipText(ResourceBundle.getBundle("resources.lenguajes.Lenguaje").getString("menu_ajustes"));
		ayuda = new MenuBasico(ResourceBundle.getBundle("resources.lenguajes.Lenguaje").getString("menu_ayuda"));
		ayuda.setToolTipText(ResourceBundle.getBundle("resources.lenguajes.Lenguaje").getString("menu_ayuda"));
		insertar = new MenuBasico(ResourceBundle.getBundle("resources.lenguajes.Lenguaje").getString("menu_insertar"));
		insertar.setToolTipText(ResourceBundle.getBundle("resources.lenguajes.Lenguaje").getString("menu_insertar"));

		// Submenus
		nuevo = new MenuItem(ResourceBundle.getBundle("resources.lenguajes.Lenguaje").getString("submenu_nuevo"));
		nuevo.setToolTipText(ResourceBundle.getBundle("resources.lenguajes.Lenguaje").getString("submenu_nuevo"));
		nuevo.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				nuevo();
			}
		});
		try {
			Icon nuev = new ImageIcon(new ImageIcon("./src/resources/icons/nuevo.png").getImage().getScaledInstance(40,
					40, Image.SCALE_SMOOTH));
			nuevo.setIcon(nuev);
		} catch (Exception e) {

		}

		guardar = new MenuItem(ResourceBundle.getBundle("resources.lenguajes.Lenguaje").getString("submenu_guardar"));
		guardar.setToolTipText(ResourceBundle.getBundle("resources.lenguajes.Lenguaje").getString("submenu_guardar"));
		guardar.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				guardar();
			}
		});
		try {
			Icon guarda = new ImageIcon(new ImageIcon("./src/resources/icons/guardar.png").getImage()
					.getScaledInstance(40, 40, Image.SCALE_SMOOTH));
			guardar.setIcon(guarda);
		} catch (Exception e) {

		}

		fuente = new MenuBasico(ResourceBundle.getBundle("resources.lenguajes.Lenguaje").getString("submenu_fuente"));
		fuente.setToolTipText(ResourceBundle.getBundle("resources.lenguajes.Lenguaje").getString("submenu_fuente"));
		try {
			Icon fuen = new ImageIcon(new ImageIcon("./src/resources/icons/fuente.png").getImage().getScaledInstance(50,
					50, Image.SCALE_SMOOTH));
			fuente.setIcon(fuen);
		} catch (Exception e) {

		}

		// A�ADIMOS NEGRITA CURSIVA Y SUBRAYADO
		negrita = new MenuItem(ResourceBundle.getBundle("resources.lenguajes.Lenguaje").getString("negrita"));
		negrita.setToolTipText(ResourceBundle.getBundle("resources.lenguajes.Lenguaje").getString("negrita"));
		negrita.addActionListener(new StyledEditorKit.BoldAction());
		try {
			Icon negr = new ImageIcon(new ImageIcon("./src/resources/icons/negrita.png").getImage()
					.getScaledInstance(40, 40, Image.SCALE_SMOOTH));
			negrita.setIcon(negr);
		} catch (Exception e) {

		}

		negrita.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_N, InputEvent.CTRL_DOWN_MASK));

		cursiva = new MenuItem(ResourceBundle.getBundle("resources.lenguajes.Lenguaje").getString("cursiva"));
		cursiva.setToolTipText(ResourceBundle.getBundle("resources.lenguajes.Lenguaje").getString("cursiva"));
		cursiva.addActionListener(new StyledEditorKit.ItalicAction());
		cursiva.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_S, InputEvent.CTRL_DOWN_MASK));
		try {
			Icon cursi = new ImageIcon(new ImageIcon("./src/resources/icons/cursiva.png").getImage()
					.getScaledInstance(40, 40, Image.SCALE_SMOOTH));
			cursiva.setIcon(cursi);
		} catch (Exception e) {

		}

		subrayado = new MenuItem(ResourceBundle.getBundle("resources.lenguajes.Lenguaje").getString("subrayado"));
		subrayado.setToolTipText(ResourceBundle.getBundle("resources.lenguajes.Lenguaje").getString("subrayado"));
		subrayado.addActionListener(new StyledEditorKit.UnderlineAction());
		subrayado.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_Z, InputEvent.CTRL_DOWN_MASK));
		try {
			Icon subra = new ImageIcon(new ImageIcon("./src/resources/icons/subrayado.png").getImage()
					.getScaledInstance(40, 40, Image.SCALE_SMOOTH));
			subrayado.setIcon(subra);
		} catch (Exception e) {

		}

		// a�adimos las opciones al menu
		fuente.add(negrita);
		fuente.add(cursiva);
		fuente.add(subrayado);

		alineacion = new MenuBasico(
				ResourceBundle.getBundle("resources.lenguajes.Lenguaje").getString("submenu_alineacion"));
		alineacion.setToolTipText(
				ResourceBundle.getBundle("resources.lenguajes.Lenguaje").getString("submenu_alineacion"));

		try {
			Icon alineacionC = new ImageIcon(new ImageIcon("./src/resources/icons/alineacionCentrada.png").getImage()
					.getScaledInstance(40, 40, Image.SCALE_SMOOTH));
			alineacion.setIcon(alineacionC);
		} catch (Exception e) {

		}

		// A�ADIMOS LAS ALINEACIONES
		aliIzq = new MenuItem(ResourceBundle.getBundle("resources.lenguajes.Lenguaje").getString("ali_izquierda"));
		aliIzq.setToolTipText(ResourceBundle.getBundle("resources.lenguajes.Lenguaje").getString("ali_izquierda"));
		aliIzq.addActionListener(new StyledEditorKit.AlignmentAction(null, StyleConstants.ALIGN_LEFT));
		try {
			Icon aliiz = new ImageIcon(new ImageIcon("./src/resources/icons/alineacionIzquierda.png").getImage()
					.getScaledInstance(40, 40, Image.SCALE_SMOOTH));
			aliIzq.setIcon(aliiz);
		} catch (Exception e) {

		}

		aliIzq.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_H, InputEvent.CTRL_DOWN_MASK));

		aliCentra = new MenuItem(ResourceBundle.getBundle("resources.lenguajes.Lenguaje").getString("ali_centro"));
		aliCentra.setToolTipText(ResourceBundle.getBundle("resources.lenguajes.Lenguaje").getString("ali_centro"));
		aliCentra.addActionListener(new StyledEditorKit.AlignmentAction(null, StyleConstants.ALIGN_CENTER));
		try {
			Icon alicen = new ImageIcon(new ImageIcon("./src/resources/icons/alineacionCentrada.png").getImage()
					.getScaledInstance(40, 40, Image.SCALE_SMOOTH));
			aliCentra.setIcon(alicen);
		} catch (Exception e) {

		}

		aliCentra.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_J, InputEvent.CTRL_DOWN_MASK));

		aliDer = new MenuItem(ResourceBundle.getBundle("resources.lenguajes.Lenguaje").getString("ali_derecha"));
		aliDer.setToolTipText(ResourceBundle.getBundle("resources.lenguajes.Lenguaje").getString("ali_derecha"));
		aliDer.addActionListener(new StyledEditorKit.AlignmentAction(null, StyleConstants.ALIGN_RIGHT));
		try {
			Icon alide = new ImageIcon(new ImageIcon("./src/resources/icons/alineacionDerecha.png").getImage()
					.getScaledInstance(40, 40, Image.SCALE_SMOOTH));
			aliDer.setIcon(alide);
		} catch (Exception e) {

		}

		aliDer.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_K, InputEvent.CTRL_DOWN_MASK));

		aliJust = new MenuItem(ResourceBundle.getBundle("resources.lenguajes.Lenguaje").getString("ali_justificada"));
		aliJust.setToolTipText(ResourceBundle.getBundle("resources.lenguajes.Lenguaje").getString("ali_justificada"));
		aliJust.addActionListener(new StyledEditorKit.AlignmentAction(null, StyleConstants.ALIGN_JUSTIFIED));
		try {
			Icon alij = new ImageIcon(new ImageIcon("./src/resources/icons/alineacionJustificada.png").getImage()
					.getScaledInstance(40, 40, Image.SCALE_SMOOTH));
			aliJust.setIcon(alij);
		} catch (Exception e) {

		}

		aliJust.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_L, InputEvent.CTRL_DOWN_MASK));

		// a�adimos las alineaciones al menu
		alineacion.add(aliIzq);
		alineacion.add(aliCentra);
		alineacion.add(aliDer);
		alineacion.add(aliJust);

		idioma = new MenuBasico(ResourceBundle.getBundle("resources.lenguajes.Lenguaje").getString("submenu_idioma"));
		idioma.setToolTipText(ResourceBundle.getBundle("resources.lenguajes.Lenguaje").getString("submenu_idioma"));

		try {
			Icon idio = new ImageIcon(new ImageIcon("./src/resources/icons/idioma.png").getImage().getScaledInstance(40,
					40, Image.SCALE_SMOOTH));
			idioma.setIcon(idio);
		} catch (Exception e) {

		}

		idiomaEspaniol = new MenuItem("Espa�ol");
		idiomaEspaniol.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				cambiarIdioma("es");

			}

		});
		idiomaIngles = new MenuItem("English");
		idiomaIngles.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				cambiarIdioma("en");
			}

		});
		// a�adimos los iconos a los dos idiomas
		try {
			Icon espa = new ImageIcon(new ImageIcon("./src/resources/icons/spain.png").getImage().getScaledInstance(40,
					40, Image.SCALE_SMOOTH));
			idiomaEspaniol.setIcon(espa);
			Icon eng = new ImageIcon(new ImageIcon("./src/resources/icons/england.png").getImage().getScaledInstance(40,
					40, Image.SCALE_SMOOTH));
			idiomaIngles.setIcon(eng);
		} catch (Exception e) {

		}

		idioma.add(idiomaEspaniol);
		idioma.add(idiomaIngles);

		interfaz = new MenuBasico(
				ResourceBundle.getBundle("resources.lenguajes.Lenguaje").getString("submenu_interfaz"));
		interfaz.setToolTipText(ResourceBundle.getBundle("resources.lenguajes.Lenguaje").getString("submenu_interfaz"));
		try {
			Icon inter = new ImageIcon(new ImageIcon("./src/resources/icons/interfaz.png").getImage()
					.getScaledInstance(40, 40, Image.SCALE_SMOOTH));
			interfaz.setIcon(inter);
		} catch (Exception e) {

		}

		imagen = new MenuItem(ResourceBundle.getBundle("resources.lenguajes.Lenguaje").getString("submenu_imagen"));
		imagen.setToolTipText(ResourceBundle.getBundle("resources.lenguajes.Lenguaje").getString("submenu_imagen"));
		imagen.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				imagen();
			}
		});
		try {
			Icon img = new ImageIcon(new ImageIcon("./src/resources/icons/imagen.png").getImage().getScaledInstance(40,
					40, Image.SCALE_SMOOTH));
			imagen.setIcon(img);
		} catch (Exception e) {

		}

		imagen.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_I, InputEvent.CTRL_DOWN_MASK));

		acerca_del_programa = new MenuItem(
				ResourceBundle.getBundle("resources.lenguajes.Lenguaje").getString("submenu_acerca"));
		acerca_del_programa
				.setToolTipText(ResourceBundle.getBundle("resources.lenguajes.Lenguaje").getString("submenu_acerca"));
		acerca_del_programa.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				acerca();
			}
		});
		acerca_del_programa.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_P, InputEvent.CTRL_DOWN_MASK));
		try {
			Icon acerc = new ImageIcon(new ImageIcon("./src/resources/icons/acerca.png").getImage()
					.getScaledInstance(40, 40, Image.SCALE_SMOOTH));
			acerca_del_programa.setIcon(acerc);
		} catch (Exception e) {

		}

		// A�adimos el look and feel
		LookAndFeelInfo[] auxiliar = UIManager.getInstalledLookAndFeels();
		for (LookAndFeelInfo a : auxiliar) {
			MenuItem aux = new MenuItem(a.getName());
			aux.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					try {
						UIManager.setLookAndFeel(a.getClassName());
						SwingUtilities.updateComponentTreeUI(accesibilidad);
					} catch (ClassNotFoundException e1) {
					} catch (InstantiationException e1) {
					} catch (IllegalAccessException e1) {
					} catch (UnsupportedLookAndFeelException e1) {
					}

				}
			});
			interfaz.add(aux);
		}

		// Adicion de submenus a los menus
		archivo.add(nuevo);
		archivo.add(guardar);
		formato.add(fuente);
		formato.add(alineacion);
		ajustes.add(idioma);
		ajustes.add(interfaz);
		insertar.add(imagen);
		ayuda.add(acerca_del_programa);

		// Implementacion
		this.add(archivo);
		this.add(insertar);
		this.add(formato);
		this.add(ajustes);
		this.add(ayuda);

		// Darle vision
		this.setBounds(0, 0, 500, 100);

	}

	public void guardar() {
		guardarArchivoVentana();
	}

	public void imagen() {
		JFileChooser chooser = new JFileChooser();
		int returnVal = chooser.showOpenDialog(accesibilidad);
		if (returnVal == JFileChooser.APPROVE_OPTION) {
			File imgToTake = chooser.getSelectedFile();
			try {
				accesibilidad.getPanelGeneral().getPanelEditor().getPanelScroll().getPanelTexto()
						.insertIcon(new ImageIcon(imgToTake.getAbsolutePath()));
			} catch (Exception e) {

			}

		}

	}

	public void nuevo() {
		JFrame confirmarBorrar = new JFrame();
		confirmarBorrar.setLayout(null);
		confirmarBorrar.setMinimumSize(new Dimension(300, 150));
		try {
			confirmarBorrar.setIconImage(new ImageIcon("./src/resources/icons/acerca.png").getImage());
		} catch (Exception e) {

		}
		JButton si = new JButton();
		si.setBounds(60, 50, 50, 25);
		JButton no = new JButton();
		no.setBounds(180, 50, 50, 25);
		si.setText(ResourceBundle.getBundle("resources.lenguajes.Lenguaje").getString("si"));
		no.setText(ResourceBundle.getBundle("resources.lenguajes.Lenguaje").getString("no"));
		JLabel texto = new JLabel(
				ResourceBundle.getBundle("resources.lenguajes.Lenguaje").getString("borrar_documento_label"),
				SwingConstants.CENTER);
		texto.setBounds(50, 0, 200, 30);
		confirmarBorrar.add(si);
		confirmarBorrar.add(no);
		confirmarBorrar.add(texto);
		// a�adimos la funcionalidad a cada boton
		si.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				accesibilidad.getPanelGeneral().getPanelEditor().getPanelScroll().getPanelTexto().setText("");
				confirmarBorrar.setVisible(false);
			}

		});
		no.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				confirmarBorrar.setVisible(false);
			}

		});
		confirmarBorrar.setVisible(true);
	}

	public void acerca() {
		// Vamos a crear un nuevo frame o mensaje
		JFrame ventanaAcerca = new JFrame();
		ventanaAcerca.setLayout(null);
		ventanaAcerca.setMinimumSize(new Dimension(800, 150));
		// Titulo de la ventana
		String titulo = ResourceBundle.getBundle("resources.lenguajes.Lenguaje").getString("titulo_ventana_acerca");
		ventanaAcerca.setTitle(titulo);
		// le ponemos el icono de acerca
		try {
			ventanaAcerca.setIconImage(new ImageIcon("./src/resources/icons/acerca.png").getImage());
		} catch (Exception e) {

		}
		JLabel texto = new JLabel();
		texto.setText(ResourceBundle.getBundle("resources.lenguajes.Lenguaje").getString("acerca_texto"));
		texto.setBounds(50, 0, 700, 100);
		ventanaAcerca.add(texto);
		ventanaAcerca.setVisible(true);
	}

	public void guardarArchivoVentana() {
		JFileChooser fileChooser = new JFileChooser();
		fileChooser.setDialogTitle(
				ResourceBundle.getBundle("resources.lenguajes.Lenguaje").getString("guardar_un_archivo"));
		int userSelection = fileChooser.showSaveDialog(accesibilidad);

		if (userSelection == JFileChooser.APPROVE_OPTION) {
			String nombreArchivo = fileChooser.getSelectedFile().getAbsolutePath() + ".dani";
			StyledDocument documento = (StyledDocument) accesibilidad.getPanelGeneral().getPanelEditor()
					.getPanelScroll().getPanelTexto().getDocument();
			RTFEditorKit elKit = new RTFEditorKit();
			BufferedOutputStream buffer;
			try {
				buffer = new BufferedOutputStream(new FileOutputStream(nombreArchivo));
				elKit.write(buffer, documento, documento.getStartPosition().getOffset(), documento.getLength());
				buffer.flush();
				buffer.close();
			} catch (Exception e) {
				System.out.println("Error al guardar el archivo");
			}
		}
	}

	public void cambiarIdioma(String idioma) {
		Locale idiomaPrograma = new Locale(idioma.toLowerCase(), idioma.toUpperCase());
		Locale.setDefault(idiomaPrograma);
		accesibilidad.setVisible(false);
		Ventana ventana = new Ventana();
	}

	public Ventana getAccesibilidad() {
		return accesibilidad;
	}

	public void setAccesibilidad(Ventana accesibilidad) {
		this.accesibilidad = accesibilidad;
	}

	public MenuBasico getArchivo() {
		return archivo;
	}

	public void setArchivo(MenuBasico archivo) {
		this.archivo = archivo;
	}

	public MenuBasico getFormato() {
		return formato;
	}

	public void setFormato(MenuBasico formato) {
		this.formato = formato;
	}

	public MenuBasico getInsertar() {
		return insertar;
	}

	public void setInsertar(MenuBasico insertar) {
		this.insertar = insertar;
	}

	public MenuBasico getAjustes() {
		return ajustes;
	}

	public void setAjustes(MenuBasico ajustes) {
		this.ajustes = ajustes;
	}

	public MenuBasico getAyuda() {
		return ayuda;
	}

	public void setAyuda(MenuBasico ayuda) {
		this.ayuda = ayuda;
	}

	public MenuBasico getFuente() {
		return fuente;
	}

	public void setFuente(MenuBasico fuente) {
		this.fuente = fuente;
	}

	public MenuBasico getAlineacion() {
		return alineacion;
	}

	public void setAlineacion(MenuBasico alineacion) {
		this.alineacion = alineacion;
	}

	public MenuBasico getInterfaz() {
		return interfaz;
	}

	public void setInterfaz(MenuBasico interfaz) {
		this.interfaz = interfaz;
	}

	public MenuItem getNuevo() {
		return nuevo;
	}

	public void setNuevo(MenuItem nuevo) {
		this.nuevo = nuevo;
	}

	public MenuItem getGuardar() {
		return guardar;
	}

	public void setGuardar(MenuItem guardar) {
		this.guardar = guardar;
	}

	public MenuItem getNegrita() {
		return negrita;
	}

	public void setNegrita(MenuItem negrita) {
		this.negrita = negrita;
	}

	public MenuItem getCursiva() {
		return cursiva;
	}

	public void setCursiva(MenuItem cursiva) {
		this.cursiva = cursiva;
	}

	public MenuItem getSubrayado() {
		return subrayado;
	}

	public void setSubrayado(MenuItem subrayado) {
		this.subrayado = subrayado;
	}

	public MenuItem getAliIzq() {
		return aliIzq;
	}

	public void setAliIzq(MenuItem aliIzq) {
		this.aliIzq = aliIzq;
	}

	public MenuItem getAliDer() {
		return aliDer;
	}

	public void setAliDer(MenuItem aliDer) {
		this.aliDer = aliDer;
	}

	public MenuItem getAliJust() {
		return aliJust;
	}

	public void setAliJust(MenuItem aliJust) {
		this.aliJust = aliJust;
	}

	public MenuItem getAliCentra() {
		return aliCentra;
	}

	public void setAliCentra(MenuItem aliCentra) {
		this.aliCentra = aliCentra;
	}

	public MenuItem getImagen() {
		return imagen;
	}

	public void setImagen(MenuItem imagen) {
		this.imagen = imagen;
	}

	public MenuItem getAcerca_del_programa() {
		return acerca_del_programa;
	}

	public void setAcerca_del_programa(MenuItem acerca_del_programa) {
		this.acerca_del_programa = acerca_del_programa;
	}

}
