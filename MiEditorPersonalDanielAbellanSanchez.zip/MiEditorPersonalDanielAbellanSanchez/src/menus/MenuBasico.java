package menus;

import java.awt.Color;

import javax.swing.JMenu;

public class MenuBasico extends JMenu {

	public MenuBasico(String texto) {
		this.setText(texto);
		this.setOpaque(true);
		this.setBackground(Color.white);
	}
}
