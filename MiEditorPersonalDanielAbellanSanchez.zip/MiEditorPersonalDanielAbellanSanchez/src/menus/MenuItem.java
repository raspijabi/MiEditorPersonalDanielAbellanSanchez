package menus;

import java.awt.Color;

import javax.swing.JMenuItem;

public class MenuItem extends JMenuItem {

	// hay que a�adir el icono al constructor
	public MenuItem(String texto) {
		this.setText(texto);
		this.setOpaque(true);
		this.setBackground(Color.white);
	}
}
