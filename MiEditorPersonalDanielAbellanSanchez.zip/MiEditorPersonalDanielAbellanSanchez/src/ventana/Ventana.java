package ventana;

import java.awt.Dimension;
import java.util.ResourceBundle;

import javax.swing.ImageIcon;
import javax.swing.JFrame;

import hiloCoherencia.Coherencia;
import menus.MenuPrincipal;
import paneles.PanelGeneral;

public class Ventana extends JFrame {

	// Declaracion de variables
	private String titulo;
	private MenuPrincipal menuPrincipal;
	private PanelGeneral panelGeneral;
	private Coherencia coherencia;

	public Ventana() {

		// Atributos Frame
		this.setLayout(null);
		this.setExtendedState(JFrame.MAXIMIZED_BOTH);
		this.setMinimumSize(new Dimension(1000, 600));

		// Titulo de la ventana
		titulo = ResourceBundle.getBundle("resources.lenguajes.Lenguaje").getString("titulo_ventana_principal");
		this.setTitle(titulo);
		// Icono de la ventana
		try {
			this.setIconImage(new ImageIcon("./src/resources/icons/iconoEditor.png").getImage());
		} catch (Exception e) {

		}

		// Panel General
		panelGeneral = new PanelGeneral();
		this.add(panelGeneral);

		// Men�s
		menuPrincipal = new MenuPrincipal();
		this.setJMenuBar(menuPrincipal);

		// coherencia
		coherencia = new Coherencia();

		// A�ADIMOS LA ACCESIBILIDAD
		panelGeneral.setAccesibilidad(this);
		menuPrincipal.setAccesibilidad(this);
		panelGeneral.getPanelEditor().getPanelScroll().getPanelTexto().getMenuContextual().setAccesibilidad(this);
		panelGeneral.getPanelEditor().getPanelScroll().getPanelTexto().setAccesibilidad(this);
		panelGeneral.getBarraHerramientas().setAccesibilidad(this);
		coherencia.accesibilidad = this;

		// Llamamos a la coherencia para que este desde el principio
		panelGeneral.getPanelEditor().getPanelScroll().getPanelTexto().coherenciaDeLaInterfaz();

		// Hacemos visible el frame
		this.setVisible(true);

		Thread coherente = new Thread(coherencia);
		coherente.start();

	}

	public PanelGeneral getPanelGeneral() {
		return panelGeneral;
	}

	public void setPanelGeneral(PanelGeneral panelGeneral) {
		this.panelGeneral = panelGeneral;
	}

	public MenuPrincipal getMenuPrincipal() {
		return menuPrincipal;
	}

	public void setMenuPrincipal(MenuPrincipal menuPrincipal) {
		this.menuPrincipal = menuPrincipal;
	}

}
