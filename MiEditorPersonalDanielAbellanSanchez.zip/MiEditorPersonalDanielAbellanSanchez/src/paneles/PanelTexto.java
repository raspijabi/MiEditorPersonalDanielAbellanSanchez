
package paneles;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JTextPane;
import javax.swing.text.AttributeSet;
import javax.swing.text.StyleConstants;

import componentes.MenuContextual;
import ventana.Ventana;

public class PanelTexto extends JTextPane implements MouseListener, KeyListener {

	private MenuContextual menuContextual;
	private Ventana accesibilidad;
	private int cursor;

	public PanelTexto(int ancho, int largo) {

		// Atributos del panel
		this.setBounds(0, 0, ancho, largo);
		this.setFont(new Font("SANS_SERIF", 0, 20));
		this.setFocusable(true);
		// LISTENERS
		addMouseListener(this);
		addKeyListener(this);

		// ponemos el estilo que es

		// MENU CONTEXTUAL
		menuContextual = new MenuContextual();
		this.setComponentPopupMenu(menuContextual);

	}

	public void ocultarMenuContextual() {
		menuContextual.setVisible(false);
	}

	public void verMenuContextual() {
		menuContextual.setVisible(true);
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		// IMPLEMENTAR METODO PARA CAMBIAR COHERENCIA EN LA INTERFAZ
		coherenciaDeLaInterfaz();
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mousePressed(MouseEvent e) {
		int tecla = e.getButton();
		if (tecla == MouseEvent.BUTTON3) {
			menuContextual.setLocation(e.getLocationOnScreen());
			verMenuContextual();
		}
		if (tecla == MouseEvent.BUTTON1) {
			ocultarMenuContextual();
		}

		// aqui igual que mouse clicked
		coherenciaDeLaInterfaz();

	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	public void coherenciaDeLaInterfaz() {
		cursor = this.getCaretPosition();
		AttributeSet parrafo = this.getStyledDocument().getParagraphElement(cursor - 1).getAttributes();
		AttributeSet estilo = this.getStyledDocument().getCharacterElement(cursor - 1).getAttributes();
		// para la fuente
		String fuente = this.getStyledDocument().getFont(estilo).getFamily();
		cambiarFuenteSeleccionada(fuente);
		// para el tama�o de la fuente
		int tamanyo = this.getStyledDocument().getFont(estilo).getSize();
		cambiarTamanyoSeleccionado(tamanyo);
		// Si esta en negrita
		if (this.getStyledDocument().getFont(estilo).isBold()) {
			ponerNegritaTodo(true);
		} else {
			ponerNegritaTodo(false);
		}
		// Si esta en cursiva
		if (this.getStyledDocument().getFont(estilo).isItalic()) {
			ponerItalicTodo(true);
		} else {
			ponerItalicTodo(false);
		}
		// si esta subrayado
		if (estilo.containsAttribute(StyleConstants.Underline, true)) {
			ponerSubrayadoTodo(true);
		} else {
			ponerSubrayadoTodo(false);
		}
		// para la alineacion
		// izquierda
		if (parrafo.containsAttribute(StyleConstants.Alignment, StyleConstants.ALIGN_LEFT)) {
			ponerAligIzquierdaTodo(true);
		} else {
			ponerAligIzquierdaTodo(false);
		}
		// derecha
		if (parrafo.containsAttribute(StyleConstants.Alignment, StyleConstants.ALIGN_RIGHT)) {
			ponerAligDerechaTodo(true);
		} else {
			ponerAligDerechaTodo(false);
		}
		// centrada
		if (parrafo.containsAttribute(StyleConstants.Alignment, StyleConstants.ALIGN_CENTER)) {
			ponerAligCentradaTodo(true);
		} else {
			ponerAligCentradaTodo(false);
		}
		// justificada
		if (parrafo.containsAttribute(StyleConstants.Alignment, StyleConstants.ALIGN_JUSTIFIED)) {
			ponerAligJustificadaTodo(true);
		} else {
			ponerAligJustificadaTodo(false);
		}

	}

	public void ponerAligIzquierdaTodo(boolean activo) {
		// Esta en barra de herramientas, menu contextual y menu formato
		// barra de tareas
		accesibilidad.getPanelGeneral().getBarraHerramientas().getAlineacionIzq().setSelected(activo);
		if (activo) {
			// Menu contextual
			accesibilidad.getPanelGeneral().getPanelEditor().getPanelScroll().getPanelTexto().getMenuContextual()
					.getAliIzq().setOpaque(true);
			accesibilidad.getPanelGeneral().getPanelEditor().getPanelScroll().getPanelTexto().getMenuContextual()
					.getAliIzq().setBackground(Color.gray);
			// Menu formato
			accesibilidad.getMenuPrincipal().getAliIzq().setOpaque(true);
			accesibilidad.getMenuPrincipal().getAliIzq().setBackground(Color.gray);
		} else {
			// Menu contextual
			accesibilidad.getPanelGeneral().getPanelEditor().getPanelScroll().getPanelTexto().getMenuContextual()
					.getAliIzq().setOpaque(true);
			accesibilidad.getPanelGeneral().getPanelEditor().getPanelScroll().getPanelTexto().getMenuContextual()
					.getAliIzq().setBackground(Color.white);
			// Menu formato
			accesibilidad.getMenuPrincipal().getAliIzq().setOpaque(true);
			accesibilidad.getMenuPrincipal().getAliIzq().setBackground(Color.white);
		}
	}

	public void ponerAligDerechaTodo(boolean activo) {
		accesibilidad.getPanelGeneral().getBarraHerramientas().getAlineacionDer().setSelected(activo);
		if (activo) {
			// Menu contextual
			accesibilidad.getPanelGeneral().getPanelEditor().getPanelScroll().getPanelTexto().getMenuContextual()
					.getAliDere().setOpaque(true);
			accesibilidad.getPanelGeneral().getPanelEditor().getPanelScroll().getPanelTexto().getMenuContextual()
					.getAliDere().setBackground(Color.gray);
			// Menu formato
			accesibilidad.getMenuPrincipal().getAliDer().setOpaque(true);
			accesibilidad.getMenuPrincipal().getAliDer().setBackground(Color.gray);
		} else {
			// Menu contextual
			accesibilidad.getPanelGeneral().getPanelEditor().getPanelScroll().getPanelTexto().getMenuContextual()
					.getAliDere().setOpaque(true);
			accesibilidad.getPanelGeneral().getPanelEditor().getPanelScroll().getPanelTexto().getMenuContextual()
					.getAliDere().setBackground(Color.white);
			// Menu formato
			accesibilidad.getMenuPrincipal().getAliDer().setOpaque(true);
			accesibilidad.getMenuPrincipal().getAliDer().setBackground(Color.white);
		}
	}

	public void ponerAligCentradaTodo(boolean activo) {
		accesibilidad.getPanelGeneral().getBarraHerramientas().getAlineacionCen().setSelected(activo);
		if (activo) {
			// Menu contextual
			accesibilidad.getPanelGeneral().getPanelEditor().getPanelScroll().getPanelTexto().getMenuContextual()
					.getAliCentro().setOpaque(true);
			accesibilidad.getPanelGeneral().getPanelEditor().getPanelScroll().getPanelTexto().getMenuContextual()
					.getAliCentro().setBackground(Color.gray);
			// Menu formato
			accesibilidad.getMenuPrincipal().getAliCentra().setOpaque(true);
			accesibilidad.getMenuPrincipal().getAliCentra().setBackground(Color.gray);
		} else {
			// Menu contextual
			accesibilidad.getPanelGeneral().getPanelEditor().getPanelScroll().getPanelTexto().getMenuContextual()
					.getAliCentro().setOpaque(true);
			accesibilidad.getPanelGeneral().getPanelEditor().getPanelScroll().getPanelTexto().getMenuContextual()
					.getAliCentro().setBackground(Color.white);
			// Menu formato
			accesibilidad.getMenuPrincipal().getAliCentra().setOpaque(true);
			accesibilidad.getMenuPrincipal().getAliCentra().setBackground(Color.white);
		}
	}

	public void ponerAligJustificadaTodo(boolean activo) {
		accesibilidad.getPanelGeneral().getBarraHerramientas().getAlineacionJust().setSelected(activo);
		if (activo) {
			// Menu contextual
			accesibilidad.getPanelGeneral().getPanelEditor().getPanelScroll().getPanelTexto().getMenuContextual()
					.getAliJustifi().setOpaque(true);
			accesibilidad.getPanelGeneral().getPanelEditor().getPanelScroll().getPanelTexto().getMenuContextual()
					.getAliJustifi().setBackground(Color.gray);
			// Menu formato
			accesibilidad.getMenuPrincipal().getAliJust().setOpaque(true);
			accesibilidad.getMenuPrincipal().getAliJust().setBackground(Color.gray);
		} else {
			// Menu contextual
			accesibilidad.getPanelGeneral().getPanelEditor().getPanelScroll().getPanelTexto().getMenuContextual()
					.getAliJustifi().setOpaque(true);
			accesibilidad.getPanelGeneral().getPanelEditor().getPanelScroll().getPanelTexto().getMenuContextual()
					.getAliJustifi().setBackground(Color.white);
			// Menu formato
			accesibilidad.getMenuPrincipal().getAliJust().setOpaque(true);
			accesibilidad.getMenuPrincipal().getAliJust().setBackground(Color.white);
		}
	}

	public void ponerNegritaTodo(boolean activo) {
		// ESTA EN: BARRA DE HERRAMIENTAS, MENU CONTEXTUAL Y MENU FORMATO NEGRITA
		// Barra de herramientas
		accesibilidad.getPanelGeneral().getBarraHerramientas().getNegrita().setSelected(activo);
		if (activo) {
			// esto es si lo activamos
			// Menu contextual
			accesibilidad.getPanelGeneral().getPanelEditor().getPanelScroll().getPanelTexto().getMenuContextual()
					.getNegrita().setOpaque(true);
			accesibilidad.getPanelGeneral().getPanelEditor().getPanelScroll().getPanelTexto().getMenuContextual()
					.getNegrita().setBackground(Color.gray);
			// Menu formato
			accesibilidad.getMenuPrincipal().getNegrita().setOpaque(true);
			accesibilidad.getMenuPrincipal().getNegrita().setBackground(Color.gray);
		} else {
			// si lo desactivamos
			// Menu contextual
			accesibilidad.getPanelGeneral().getPanelEditor().getPanelScroll().getPanelTexto().getMenuContextual()
					.getNegrita().setOpaque(true);
			accesibilidad.getPanelGeneral().getPanelEditor().getPanelScroll().getPanelTexto().getMenuContextual()
					.getNegrita().setBackground(Color.white);
			// Menu formato
			accesibilidad.getMenuPrincipal().getNegrita().setOpaque(true);
			accesibilidad.getMenuPrincipal().getNegrita().setBackground(Color.white);
		}

	}

	public void ponerItalicTodo(boolean activo) {
		// igual que negrita en barra de herramientas, menu contextual y menu formato
		// cursiva
		// barra de herramientas
		accesibilidad.getPanelGeneral().getBarraHerramientas().getCursiva().setSelected(activo);
		if (activo) {
			// Menu contextual
			accesibilidad.getPanelGeneral().getPanelEditor().getPanelScroll().getPanelTexto().getMenuContextual()
					.getCursiva().setOpaque(true);
			accesibilidad.getPanelGeneral().getPanelEditor().getPanelScroll().getPanelTexto().getMenuContextual()
					.getCursiva().setBackground(Color.gray);
			// Menu formato
			accesibilidad.getMenuPrincipal().getCursiva().setOpaque(true);
			accesibilidad.getMenuPrincipal().getCursiva().setBackground(Color.gray);
		} else {
			// Menu contextual
			accesibilidad.getPanelGeneral().getPanelEditor().getPanelScroll().getPanelTexto().getMenuContextual()
					.getCursiva().setOpaque(true);
			accesibilidad.getPanelGeneral().getPanelEditor().getPanelScroll().getPanelTexto().getMenuContextual()
					.getCursiva().setBackground(Color.white);
			// Menu formato
			accesibilidad.getMenuPrincipal().getCursiva().setOpaque(true);
			accesibilidad.getMenuPrincipal().getCursiva().setBackground(Color.white);
		}
	}

	public void ponerSubrayadoTodo(boolean activo) {
		// barra de herramientas
		accesibilidad.getPanelGeneral().getBarraHerramientas().getSubrayado().setSelected(activo);
		if (activo) {
			// Menu contextual
			accesibilidad.getPanelGeneral().getPanelEditor().getPanelScroll().getPanelTexto().getMenuContextual()
					.getSubrayado().setOpaque(true);
			accesibilidad.getPanelGeneral().getPanelEditor().getPanelScroll().getPanelTexto().getMenuContextual()
					.getSubrayado().setBackground(Color.gray);
			// Menu formato
			accesibilidad.getMenuPrincipal().getSubrayado().setOpaque(true);
			accesibilidad.getMenuPrincipal().getSubrayado().setBackground(Color.gray);
		} else {
			// Menu contextual
			accesibilidad.getPanelGeneral().getPanelEditor().getPanelScroll().getPanelTexto().getMenuContextual()
					.getCursiva().setOpaque(true);
			accesibilidad.getPanelGeneral().getPanelEditor().getPanelScroll().getPanelTexto().getMenuContextual()
					.getCursiva().setBackground(Color.white);
			// Menu formato
			accesibilidad.getMenuPrincipal().getCursiva().setOpaque(true);
			accesibilidad.getMenuPrincipal().getCursiva().setBackground(Color.white);
		}
	}

	public void cambiarTamanyoSeleccionado(int tamanyo) {
		// aqui solo esta en la barra de herramientas
		for (int i = 0; i < accesibilidad.getPanelGeneral().getBarraHerramientas().getArrayTama().size(); i++) {
			if (tamanyo == accesibilidad.getPanelGeneral().getBarraHerramientas().getArrayTama().get(i)) {
				accesibilidad.getPanelGeneral().getBarraHerramientas().getListaDesplegableTamanyo().setSelectedIndex(i);
			}
		}
	}

	public void cambiarFuenteSeleccionada(String fuente) {
		// solo en la barra de herramientas
		for (int i = 0; i < accesibilidad.getPanelGeneral().getBarraHerramientas().getArray().length; i++) {
			if (fuente.equals(accesibilidad.getPanelGeneral().getBarraHerramientas().getListaDesplegableFuentes()
					.getItemAt(i).toString())) {
				accesibilidad.getPanelGeneral().getBarraHerramientas().getListaDesplegableFuentes().setSelectedIndex(i);
			}
		}
	}

	public MenuContextual getMenuContextual() {
		return menuContextual;
	}

	public void setMenuContextual(MenuContextual menuContextual) {
		this.menuContextual = menuContextual;
	}

	public Ventana getAccesibilidad() {
		return accesibilidad;
	}

	public void setAccesibilidad(Ventana accesibilidad) {
		this.accesibilidad = accesibilidad;
	}

	@Override
	public void keyPressed(KeyEvent e) {
		coherenciaDeLaInterfaz();

	}

	@Override
	public void keyReleased(KeyEvent e) {

	}

	@Override
	public void keyTyped(KeyEvent e) {

	}

}
