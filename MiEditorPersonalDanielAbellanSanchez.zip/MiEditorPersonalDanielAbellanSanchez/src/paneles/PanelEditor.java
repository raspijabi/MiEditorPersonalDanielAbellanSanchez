package paneles;

import java.awt.Color;

import javax.swing.JPanel;

import ventana.Ventana;

public class PanelEditor extends JPanel {

	private PanelScroll panelScroll;
	private Ventana accesibilidad;

	public PanelEditor() {

		// Atributos del panel
		this.setBackground(Color.blue);
		this.setLayout(null);

		// Panel Scroll
		panelScroll = new PanelScroll();
		this.add(panelScroll);

	}

	public PanelScroll getPanelScroll() {
		return panelScroll;
	}

	public void setPanelScroll(PanelScroll panelScroll) {
		this.panelScroll = panelScroll;
	}

	public Ventana getAccesibilidad() {
		return accesibilidad;
	}

	public void setAccesibilidad(Ventana accesibilidad) {
		this.accesibilidad = accesibilidad;
	}

}
