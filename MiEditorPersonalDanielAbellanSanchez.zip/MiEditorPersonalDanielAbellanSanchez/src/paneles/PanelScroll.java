package paneles;

import java.awt.Dimension;
import java.awt.Toolkit;

import javax.swing.JScrollPane;

public class PanelScroll extends JScrollPane {

	private PanelTexto panelTexto;

	public PanelScroll() {
		// atributos
		this.setLayout(null);

		// Dimension del panel
		Dimension dimensionPantalla = Toolkit.getDefaultToolkit().getScreenSize();
		int altura = dimensionPantalla.height;
		int anchura = dimensionPantalla.width;
		this.setBounds(0, 0, anchura, altura);

		// Text Panel
		panelTexto = new PanelTexto(anchura, altura);
		this.add(panelTexto);

	}

	public PanelTexto getPanelTexto() {
		return panelTexto;
	}

	public void setPanelTexto(PanelTexto panelTexto) {
		this.panelTexto = panelTexto;
	}

}
