package paneles;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Toolkit;

import javax.swing.JPanel;

import componentes.BarraDeHerramientas;
import ventana.Ventana;

public class PanelGeneral extends JPanel {

	private PanelEditor panelEditor;
	private BarraDeHerramientas barraHerramientas;
	private Ventana accesibilidad;

	public PanelGeneral() {

		// Layout
		BorderLayout borderLayout = new BorderLayout();
		this.setLayout(borderLayout);

		// Dimension del panel en funcion del pc
		Dimension dimensionPantalla = Toolkit.getDefaultToolkit().getScreenSize();
		int altura = dimensionPantalla.height;
		int anchura = dimensionPantalla.width;
		this.setBounds(0, 0, anchura, altura);

		// DIFERENTES PANELES
		// Panel del editor
		panelEditor = new PanelEditor();
		this.add(panelEditor, BorderLayout.CENTER);

		// Barra de herramientas
		barraHerramientas = new BarraDeHerramientas();
		this.add(barraHerramientas, BorderLayout.NORTH);

	}

	// METODOS PARA LA ACCESIBILIDAD DE LA INTERFAZ

	public void negritaMarcar() {
		barraHerramientas.getNegrita().setSelected(true);
	}

	public void negritaDesmarcar() {
		barraHerramientas.getNegrita().setSelected(false);
	}

	public void cursivaMarcar() {
		barraHerramientas.getCursiva().setSelected(true);
	}

	public void cursivaDesmarcar() {
		barraHerramientas.getCursiva().setSelected(false);
	}

	public void subrayadoMarcar() {
		barraHerramientas.getSubrayado().setSelected(true);
	}

	public void subrayadoDesmarcar() {
		barraHerramientas.getSubrayado().setSelected(false);
	}

	public PanelEditor getPanelEditor() {
		return panelEditor;
	}

	public void setPanelEditor(PanelEditor panelEditor) {
		this.panelEditor = panelEditor;
	}

	public BarraDeHerramientas getBarraHerramientas() {
		return barraHerramientas;
	}

	public void setBarraHerramientas(BarraDeHerramientas barraHerramientas) {
		this.barraHerramientas = barraHerramientas;
	}

	public Ventana getAccesibilidad() {
		return accesibilidad;
	}

	public void setAccesibilidad(Ventana accesibilidad) {
		this.accesibilidad = accesibilidad;
		barraHerramientas.setAccesibilidad(accesibilidad);
		panelEditor.setAccesibilidad(accesibilidad);
	}

}
